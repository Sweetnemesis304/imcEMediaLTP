<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <a href="form_imc.php">form_imc.php</a>
  <br>
    <a href="form_notas.php">form_notas.php</a>
</body>
</html>