<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action = "prog2.php"  method="GET">
        <label id="nota1">Insira nota 1:</label>
        <input type = "text" name= "nota1">
      <br>
        <label id="nota2">Insira nota 2:</label>
        <input type = "text" name= "nota2">
      <br>
        <input type = "submit" value="Enviar">
</form>

</body>
</html>